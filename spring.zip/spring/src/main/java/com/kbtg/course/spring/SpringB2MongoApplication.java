package com.kbtg.course.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringB2MongoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringB2MongoApplication.class, args);
	}

}
